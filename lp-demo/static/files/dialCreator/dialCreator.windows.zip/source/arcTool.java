import processing.core.*; 
import processing.xml.*; 

import processing.pdf.*; 
import processing.opengl.*; 
import controlP5.*; 
import java.awt.FileDialog; 
import java.text.DecimalFormat; 
import controlP5.*; 
import processing.core.PApplet; 

import controlP5.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class arcTool extends PApplet {









PFont font = createFont("Courier", 14);
Dial d;

ControlP5 controlP5;

String filename = null;

public void setup() {
  size(600, 600, OPENGL);
  frameRate(25);

  d = new Dial(16, 8, 0, 10, 5, 10, 150, PI, true, true);
  
  int leftEdge = 40;
  int controlWidth = 360;
  
  FormBuilder.Form form = new FormBuilder(this).build();
  form.addSlider("degreesSlider", "Degrees", 1, 360, d.getDegrees());
  form.addSlider("majorTicksSlider", "Major Ticks", 1, 20, d.getMajorTicks());
  form.addSlider("minorTicksSlider", "Minor Ticks", 1, 20, d.getMinorTicks());
  form.addSlider("radiusSlider", "Radius (in)", 1, 3, (int) d.getRadius());
  form.addSlider("majorTickHeightSlider", "Major Tick Height", 1, 30, d.getMajorTickLength());
  form.addSlider("minorTickHeightSlider", "Minor Tick Height", 1, 20, d.getMinorTickLength());

  
  controlP5 = new ControlP5(this);
  controlP5.addToggle("baselineToggle", true, 500, 5, 15, 15).setLabel("Baseline");
  controlP5.addToggle("axisToggle", true, 500, 35, 15, 15).setLabel("Flip Axis");
  controlP5.addButton("savePdf", 0, 500, 65, 15, 15).setLabel("Save");
  stroke(0, 0, 0);
}

public void savePdf() {
  FileDialog dialog = new FileDialog(frame, "Save Dial", FileDialog.SAVE);
  dialog.setModal(true);
  dialog.show();
  filename = dialog.getFile();
  if (filename != null) {
    filename = dialog.getDirectory() + filename;
  }
}

public void axisToggle(boolean flipAxis) {
  d.setFlipAxis(flipAxis);
}

public void baselineToggle(boolean baseline) {
  d.setIncludeBase(baseline);
}

public void addSlider(String name, String function, int min, int max, int def,
    int top, int left, int width, int height) {
  controlP5.addSlider(function, min, max, def, top, left, width, height);
}

public void degreesSlider(int degs) {
  d.setTotalRads(degs * PI / 180);
}

public void majorTicksSlider(int ticks) {
  d.setMajorTicks(ticks);
}

public void majorTickHeightSlider(int len) {
  d.setMajorTickLength(len);
}

public void minorTickHeightSlider(int len) {
  d.setMinorTickLength(len);
}

public void minorTicksSlider(int ticks) {
  d.setMinorTicks(ticks);
}

public void radiusSlider(float radius) {
  d.setRadius(radius);
}

public void draw() {
  background(155);
  if (filename != null) {
    beginRecord(PDF, filename);
    print("saving pdf to " + filename);
  }
  stroke(0);
  d.drawDial(width / 2, (height / 2) + 100);
  
  if (filename != null) {
    print("done saving");
    endRecord();
    filename = null;
  }
  stroke(0);
}




public class Dial {
  int majorTickLength;
  int minorTickLength;
  int mediumTickLength;
  float minUnit;
  float maxUnit;
  int segments;
  int subSegments;
  NumberFormat format;
  
  int radius;
  float totalRads;
  
  // Logical = scale on the dial
  float logicalSegmentSize;
  float logicalSubSegmentSize;
  
  // Physical = % of the dial
  float physicalSegmentSize;
  float physicalSubSegmentSize;
  
  boolean includeBase;
  boolean flipAxis;
  
  public Dial(int majorTickLength, int minorTickLength, float minUnit, float maxUnit, 
      int segments, int subSegments, int radius, float totalRads, 
      boolean includeBase, boolean flipAxis) {
    this.format = new DecimalFormat("0.##");
    this.majorTickLength = majorTickLength;
    this.minorTickLength = minorTickLength;
    this.minUnit = minUnit;
    this.maxUnit = maxUnit;
    this.segments = segments;
    this.subSegments = subSegments;
    this.radius = radius;
    this.totalRads = totalRads;
    this.includeBase = includeBase;
    this.flipAxis = flipAxis;
    
    // This probably should be totalRads = totalRads % 2*PI
    while (this.totalRads > 2 * PI) {
      this.totalRads = this.totalRads - 2 * PI;
    }

    recalcSegments();
  }
  
  public boolean getFlipAxis() {
    return flipAxis;
  }
  
  public void setFlipAxis(boolean flipAxis) {
    this.flipAxis = flipAxis;
  }
  
  
  public boolean getIncludeBase() {
    return includeBase;
  }
  
  public void setIncludeBase(boolean includeBase) {
    this.includeBase = includeBase;
  }

  public int getMinorTickLength() {
    return minorTickLength;
  }
  
  public void setMinorTickLength(int minorTickLength) {
    this.minorTickLength = minorTickLength;
    recalcSegments();
  }

  public int getMajorTickLength() {
    return majorTickLength;
  }
  
  public void setMajorTickLength(int majorTickLength) {
    this.majorTickLength = majorTickLength;
    recalcSegments();
  }
  
  private void recalcSegments() {
    logicalSegmentSize = (maxUnit - minUnit) / segments;
    logicalSubSegmentSize = logicalSegmentSize / subSegments;
    
    mediumTickLength = (majorTickLength + minorTickLength) / 2;
    
    physicalSegmentSize = 1.0f / segments;
    physicalSubSegmentSize = physicalSegmentSize / subSegments;
  }
  
  public float getRadius() {
    return radius / 72.0f;
  }
  
  public void setRadius(float radius) {
    this.radius = (int)(radius * 72);
    recalcSegments();
  }

  public float getTotalRads() {
    return totalRads;
  }
  
  public int getDegrees() {
    return (int) (totalRads * 180 / PI);
  }

  public void setTotalRads(float totalRads) {
    this.totalRads = totalRads;
    recalcSegments();
  }
  
  public int getMajorTicks() {
    return segments;
  }
  
  public void setMajorTicks(int ticks) {
    this.segments = ticks;
    recalcSegments();
  }
  
  public int getMinorTicks() {
    return subSegments;
  }
  
  public void setMinorTicks(int ticks) {
    this.subSegments = ticks;
    recalcSegments();
  }
  
  public void drawDial(int centerX, int centerY) {
    pushMatrix();
    translate(centerX, centerY);
    drawCrosshair();
    
    for (int i = 0; i <= segments; i += 1) {
      String segmentText = format.format((i * logicalSegmentSize) + minUnit);
      float currentMark = i / (segments * 1.0f);
      drawText(segmentText, currentMark);
      drawTick(currentMark, majorTickLength, 2);
      if (i == segments) {
        break;
      }
      for (int j = 1; j < subSegments; j += 1) {
        if (subSegments % 2 == 0 && (j == subSegments / 2)) {
          drawTick(currentMark + (j * physicalSubSegmentSize), mediumTickLength, 1.5f);
        } else {
          drawTick(currentMark + (j * physicalSubSegmentSize), minorTickLength);
        }
      }
    }
    if (includeBase) {
      drawArc();
    }
    popMatrix();
  }
  
  public void drawCrosshair() {
    line(-5, 0, 5, 0);
    line(0, -5, 0, 5);
  }
  
  public void drawText(String data) {
    noStroke();
    textAlign(CENTER);
    textFont(font);
    if (flipAxis) {
      text(data, 0, 15);
    } else {
      text(data, 0, -5);
    }
  }

  public void drawText(String data, float percent) {
    pushMatrix();
  
    if (flipAxis) {
      offsetAndRotate(percent, radius - majorTickLength);
    } else {
      offsetAndRotate(percent, radius + majorTickLength);
    }
  
    fill(0, 0, 0);
    drawText(data);
    popMatrix();
  }
  
  public void drawTick(float percent, int len) {
    drawTick(percent, len, 1);
  }
  
  public void drawTick(float percent, int len, float weight) {
    pushMatrix();
    if (flipAxis) {
      len = -len;
    }
    offsetAndRotate(percent, radius + len);
    stroke(0);
    strokeWeight(weight);
    line(0, 0, 0, len);
    strokeWeight(1);
    popMatrix();
  }
  
  public void drawArc() {
    noFill();
    stroke(0);
    
    float arcStart = 3*PI/2 -(totalRads / 2);
    float arcEnd = 3*PI/2 + (totalRads / 2);
    arc(0, 0, radius * 2, radius * 2, arcStart, arcEnd);
  }
  
  public void offsetAndRotate(float percent, float radius) {
    float rads = totalRads * percent;
    rotate(rads - (totalRads / 2));
    translate(0, -radius);  // Shifts up;  
  }
}



public class FormBuilder {
  private int spacing = 15;
  private int leftEdge = 20;
  private int top = 5;
  private int leftColumnWidth = 360;
  
  private PApplet applet;
  public FormBuilder(PApplet applet) {
    this.applet = applet;
  }
  
  public Form build() {
    return new Form(new ControlP5(applet), 0, 0, 0, 0, 0);
  }

  public class Form {
    private ControlP5 controlBuilder;
    private int cellX = 20;
    private int cellY = 5;
    private int columnWidth = 360;
    private int innerRowHeight = 20;
    private int fullRowHeight = 30;

    private Form(ControlP5 controlBuilder, int vSpacing, int hSpacing,
        int leftEdge, int top, int leftColumnWidth) {
      this.controlBuilder = controlBuilder;
    }
    
    public void addSlider(String methodName, String label, 
        int sliderMin, int sliderMax, int sliderDefault) {

      controlBuilder.addSlider(methodName, sliderMin, sliderMax, 
          sliderDefault, cellX, cellY, columnWidth, innerRowHeight).setLabel(label);
      cellY += fullRowHeight;
    }
    
    public void addSlider(String methodName, String label, 
        int sliderMin, int sliderMax, float sliderDefault) {

      controlBuilder.addSlider(methodName, sliderMin, sliderMax, 
          sliderDefault, cellX, cellY, columnWidth, innerRowHeight).setLabel(label);
      cellY += fullRowHeight;
    }
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "arcTool" });
  }
}
